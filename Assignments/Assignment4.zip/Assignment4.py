# Task 1: Write Sales Records to a File

sales = [1200, 450, 980, 1500, 3000]

with open("sales_data.txt", "w") as file:
    for sale in sales:
        file.write(str(sale) + "\n")

with open("sales_data.txt", "r") as file:
    print("File contents:")
    print(file.read())


# Task 2: Read File in Different Ways

# 1. Read the entire file using read()
with open("sales_data.txt", "r") as file:
    content = file.read()
    print("Using read():")
    print(content)


# 2. Read the first line using readline()
with open("sales_data.txt", "r") as file:
    first_line = file.readline().strip()
    print("Using readline():")
    print(first_line)


# 3. Read all lines using readlines()
with open("sales_data.txt", "r") as file:
    lines = file.readlines()
    sales_list = [int(line.strip()) for line in lines]

    print("Using readlines():")
    print(sales_list)


# Task 3: Append New Sales

new_sales = [5000, 2500, 1700]

with open("sales_data.txt", "a") as file:
    for sale in new_sales:
        file.write(str(sale) + "\n")

with open("sales_data.txt", "r") as file:
    updated_content = file.read()
    print("Updated file contents:")
    print(updated_content)


# Total number of lines after appending
with open("sales_data.txt", "r") as file:
    lines = file.readlines()
    print("Total number of lines:", len(lines))

# Task 4: Generate Summary Report from File

with open("sales_data.txt", "r") as file:
    lines = file.readlines()

sales = [int(line.strip()) for line in lines]

total_sales = sum(sales)
highest_sale = max(sales)
lowest_sale = min(sales)
average_sale = total_sales / len(sales)

print("Total Sales:", total_sales)
print("Highest Sale:", highest_sale)
print("Lowest Sale:", lowest_sale)
print("Average Sale:", average_sale)


# Task 5: Create Product Info File

products = []

for i in range(3):
    name = input("Enter product name: ")
    price = float(input("Enter product price: "))
    products.append((name, price))

with open("products.txt", "w") as file:
    for name, price in products:
        file.write(f"{name} | {price}\n")

with open("products.txt", "r") as file:
    for line in file:
        print(line.strip())


# Task 6: Read File Safely

import os

filename = input("Enter filename to open: ")

if os.path.exists(filename):
    with open(filename, "r") as file:
        print(file.read())
else:
    print("File not found. Please check the filename.")

# Task 7: Mini Project - Export Discounted Prices

prices = {
    "Mouse": 500,
    "Keyboard": 800,
    "Monitor": 7000,
    "Pendrive": 400,
    "Camera": 5000
}

discount_percent = float(input("Enter discount percentage: "))

discounted_prices = []

with open("discount_report.txt", "w") as file:
    file.write("Product | Original Price | Discounted Price\n")
    file.write("-" * 50 + "\n")

    for product, original_price in prices.items():
        discount = original_price * discount_percent / 100
        discounted_price = original_price - discount

        discounted_prices.append(discounted_price)

        file.write(
            f"{product} | {original_price:.2f} | {discounted_price:.2f}\n"
        )

    total_items = len(discounted_prices)
    average_discounted_price = sum(discounted_prices) / total_items

    file.write("\n")
    file.write(f"Total Items: {total_items}\n")
    file.write(
        f"Average Discounted Price: {average_discounted_price:.2f}\n"
    )


# Read the file and print it to the terminal

with open("discount_report.txt", "r") as file:
    print("\nDiscount Report:")
    print(file.read())