# main.py

# Task 1: Import math_utils in two different ways

import math_utils
from math_utils import square

print("Math Utilities:")
print(math_utils.add(10, 5))
print(math_utils.subtract(10, 5))
print(square(5))


# Task 2: Import string_utils

import string_utils

print("\nString Utilities:")
print(string_utils.capitalize_words("hello python world"))
print(string_utils.reverse_string("Python"))
print(string_utils.word_count("Python is easy to learn"))


# Task 4: Import package

import shop_package.discount as disc
from shop_package.billing import calculate_total

print("\nShop Package:")

print("Discounted price:", disc.apply_discount(1000, 10))
print("Flat discounted price:", disc.flat_discount(500))
print("Total bill:", calculate_total([100, 200, 300]))
print("Taxed amount:", shop_package.apply_tax(1000))


# Directly calling functions imported through __init__.py

print("Package discount:", shop_package.apply_discount(2000, 20))
print("Package flat discount:", shop_package.flat_discount(500))
print("Package total:", shop_package.calculate_total([100, 200, 300]))
print("Package tax:", shop_package.apply_tax(1000))