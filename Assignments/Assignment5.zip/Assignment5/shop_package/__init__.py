# shop_package/__init__.py

from .discount import apply_discount, flat_discount
from .billing import calculate_total, apply_tax