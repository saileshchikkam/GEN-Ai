# Task 1: Discount Rules

try:
    order_amount = float(input())

    if order_amount >= 2000:
        discount_percent = 15
    elif order_amount >= 1500:
        discount_percent = 10
    elif order_amount >= 1000:
        discount_percent = 7
    else:
        discount_percent = 0

    discount = order_amount * discount_percent / 100
    subtotal = order_amount - discount
    tax = subtotal * 5 / 100
    final_total = subtotal + tax

    print("Order Amount:", order_amount)
    print("Discount:", discount_percent, "%")
    print("Discount Amount:", discount)
    print("Subtotal:", subtotal)
    print("Tax:", tax)
    print("Final Total:", final_total)

except ValueError:
    print("Error: Please enter a valid number.")


# Task 2: Process Multiple Orders

orders = [1200, 2500, 800, 1750, 3000]

total_revenue = 0
discounted_orders = 0

print("\nOrder Amount | Discount % | Discount Amount | Final Amount")
print("-" * 60)

for order_amount in orders:

    if order_amount >= 2000:
        discount_percent = 15
    elif order_amount >= 1500:
        discount_percent = 10
    elif order_amount >= 1000:
        discount_percent = 7
    else:
        discount_percent = 0

    discount = order_amount * discount_percent / 100
    final_amount = order_amount - discount

    print(
        f"{order_amount:12.2f} | "
        f"{discount_percent:10}% | "
        f"{discount:15.2f} | "
        f"{final_amount:12.2f}"
    )

    total_revenue += final_amount

    if discount_percent > 0:
        discounted_orders += 1

print("-" * 60)
print("Total Revenue After Discounts:", total_revenue)
print("Number of Discounted Orders:", discounted_orders)

# Task 3: User Menu

orders = []

while True:
    print("\n1 - Add order amount")
    print("2 - Show all orders and totals")
    print("q - Quit")

    choice = input("Enter your choice: ")

    if choice == "1":
        try:
            amount = float(input("Enter order amount: "))
            orders.append(amount)
            print("Order added successfully.")
        except ValueError:
            print("Invalid amount.")
            continue

    elif choice == "2":
        if len(orders) == 0:
            print("No orders available.")
            continue

        total = 0

        print("\nOrder Amount | Discount % | Final Amount")
        print("-" * 40)

        for order_amount in orders:

            if order_amount >= 2000:
                discount_percent = 15
            elif order_amount >= 1500:
                discount_percent = 10
            elif order_amount >= 1000:
                discount_percent = 7
            else:
                discount_percent = 0

            discount = order_amount * discount_percent / 100
            final_amount = order_amount - discount

            print(
                f"{order_amount:12.2f} | "
                f"{discount_percent:10}% | "
                f"{final_amount:12.2f}"
            )

            total += final_amount

        print("-" * 40)
        print("Total after discounts:", total)

    elif choice == "q":
        print("Program exited.")
        break

    else:
        print("Invalid choice.")
        continue


# Task 5: Loop Control with Conditions

daily = [200, 150, 0, 400, 50, -1, 300]

total_sales = 0

for sales in daily:

    if sales == -1:
        print("Corrupted data found. Stopping processing.")
        break

    if sales == 0:
        print("No sales today. Skipping.")
        continue

    total_sales += sales
    print("Sales:", sales)
    print("Running total:", total_sales)

print("Final total sales:", total_sales)