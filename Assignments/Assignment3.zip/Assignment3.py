# Task 1: Basic Function - Price After Discount

def apply_discount(price, discount_percent=5):
    if discount_percent > 60:
        discount_percent = 60

    discount = price * discount_percent / 100
    final_price = price - discount

    return final_price


print(apply_discount(1000, 10))
print(apply_discount(500))


# Task 2: Recursive Function - Factorial Utility

def factorial(n):
    if n < 0:
        print("Error: Factorial is not defined for negative numbers.")
        return None

    if n == 0 or n == 1:
        return 1

    return n * factorial(n - 1)


print(factorial(5))
print(factorial(0))
print(factorial(-3))

# Task 3: Lambda Function - GST Calculator

gst = lambda price: price + (0.18 * price)

print(gst(100))


# Optional: GST + Discount

gst_discount = lambda price, discount: (price - (price * discount / 100)) * 1.18

print(gst_discount(1000, 10))


# Task 4: Using map() - Apply GST to List of Prices

prices = [100, 250, 400, 1200, 50]

prices_with_gst = list(map(gst, prices))

print("Original prices:", prices)
print("Prices after GST:", prices_with_gst)


# Task 5: Using filter() - Filter Expensive Products

prices = [100, 250, 400, 1200, 50, 2000, 850]

above_500 = list(filter(lambda price: price > 500, prices))
less_or_equal_500 = list(filter(lambda price: price <= 500, prices))

print("Prices greater than 500:", above_500)
print("Prices less than or equal to 500:", less_or_equal_500)


# Task 6: Combined Utility Function

def process_prices(prices):
    discounted_prices = list(
        map(lambda price: price - (price * 10 / 100), prices)
    )

    filtered_prices = list(
        filter(lambda price: price > 300, discounted_prices)
    )

    return discounted_prices, filtered_prices


discounted_prices, filtered_prices = process_prices(
    [100, 500, 900, 50, 750]
)

print("Discounted prices:", discounted_prices)
print("Filtered prices:", filtered_prices)

# Task 7

def add_price(prices_list, price):
    prices_list.append(price)


def get_average_price(prices_list):
    if len(prices_list) == 0:
        return 0
    return sum(prices_list) / len(prices_list)


def get_max_price(prices_list):
    if len(prices_list) == 0:
        return 0
    return max(prices_list)


prices = []

while True:
    print("\n1 - Add price")
    print("2 - Show average price")
    print("3 - Show highest price")
    print("q - Quit")

    choice = input("Enter your choice: ")

    if choice == "1":
        try:
            price = float(input("Enter price: "))
            add_price(prices, price)
            print("Price added successfully.")
        except ValueError:
            print("Invalid price.")

    elif choice == "2":
        if len(prices) == 0:
            print("No prices available.")
        else:
            print("Average price:", get_average_price(prices))

    elif choice == "3":
        if len(prices) == 0:
            print("No prices available.")
        else:
            print("Highest price:", get_max_price(prices))

    elif choice == "q":
        print("Program exited.")
        break

    else:
        print("Invalid choice.")